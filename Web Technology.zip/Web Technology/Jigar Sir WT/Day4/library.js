"use script";

class auth {
  constructor() {
    this.details = [
      {
        email: "john@example.com",
        password: "passw@#ord123",
      },
      {
        email: "bycycle@example.com",
        password: "Bssw@#ord123",
      },
      {
        email: "john@example.in",
        password: "TTTE@#ord123",
      },
      {
        email: "john@le.org",
        password: "p*$123",
      },
      {
        email: "joh345@xample.com",
        password: "pas#ord12",
      },
    ];
  }

  checkemail(emailid) {
    console.log(emailid);
    var exp = /^([a-zA-Z0-9]+)@([a-zA-Z0-9]+)\.([a-zA-Z]{2,})(\.[]{2,})?$/;
    var result = exp.test(emailid);
    return result;
  }
    checkpass(password) {
      
        var exp = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#\$]).{4,12}$/;
        var result = exp.test(password);
        return result;
  }
  checkemailandpass() {}
}

export default auth;
