"use strict";
import auth from "./library.js";

document.querySelector("button").onclick = function () {
  //   alert("Hello World!");
  var data1 = document.getElementById("x1").value;
  var data2 = document.getElementById("x2").value;

  //   console.log(data1, data2);

  var authObj = new auth();
  console.log(authObj);

  var ans1 = authObj.checkemail(data1);
  console.log(ans1);

  var ans2 = authObj.checkpass(data2);
  console.log(ans2);

  if (ans1 && ans2) {
    document.querySelector("p").innerHTML = "ok";
  } else {
    document.querySelector("p").innerHTML = "not ok";
  }
  authObj.checkemail(data1);
};
