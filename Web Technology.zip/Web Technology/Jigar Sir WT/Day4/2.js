"use strict";

var category = ["Eectronics", "Clothing", "Books", "Home & Garden"];

var products = [
  { 
    
    name: "Jacket",
    price: 1000,
    path:  "https://s.alicdn.com/@sc04/kf/H6e83d07de33f4dd9a31110abef88ef1dy.jpg_720x720q50.jpg",
  },
  {
    name: "Shirt",
    price: 1000,
    path: "https://s.alicdn.com/@sc04/kf/Hcee3b7c8e73c4e6d98bb936cc3285170h.jpg_720x720q50.jpg",
  },
  {
    name: "Pant",
    price: 1000,
    path: "https://s.alicdn.com/@sc04/kf/Hcfe899c4f05643608a7a672c63af50f8V.jpg_720x720q50.jpg",
  },
  {
    name: "Hoodie",
    price: 1000,
    path: "https://s.alicdn.com/@sc04/kf/H1b6721b537454ae2b37f93217ed03a7dz.jpg_720x720q50.jpg",
  },

  {
    name: "coat",
    price: 1000,
    path: "https://s.alicdn.com/@sc04/kf/H04c72fd7bc7e44dd9f3172c7f9cf988aG.jpg_720x720q50.jpg",
  },
];

// short curcite operator

category &&
  category.length > 0 &&
  category.forEach(function (v, i) {
    console.log(v, i);

    var listtag = document.createElement("li");
    console.log(listtag);

    listtag.innerHTML = v;

    document.querySelector("ul").append(listtag);
  });

products &&
  products.length > 0 &&
  products.forEach(function (v, i) {
    console.log(v, i);

    var divtag = document.createElement("div");
    console.log(divtag);

    divtag.className = "col-xl-4 text-center";

      var imgtag = document.createElement("img");
      console.log(imgtag);
      
      imgtag.src = v.path;
        imgtag.className = "img-fluid product-img";
      // imgtag.className = "img-fluid card";
    // document.getElementById("img").style.aspectRatio = "16/9";
    //document.querySelector("imgtag").style.aspectRation = "16/9";
    //   document.getElementByClass("card").style.height = "300px";
   // document.querySelector("img").style.aspectRatio = "16/9";
  // document.getElementsByTagName("img").style.aspectRatio= "16/9";
  // document.getElementsByName("img").style.aspectRatio = "16/9";

    var h2tag = document.createElement("h2");
    var ptag = document.createElement("p");

    divtag.append(imgtag, h2tag, ptag);

    imgtag.src = v.path;
    imgtag.className = "img-fluid";
    h2tag.innerHTML = v.price;
    ptag.innerHTML = v.name;

    document.getElementById("row").append(divtag);
  });

  