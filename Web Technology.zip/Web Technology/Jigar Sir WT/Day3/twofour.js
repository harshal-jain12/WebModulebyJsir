"use strict";
document.getElementById("add").onclick = function () {
  var num1 = document.getElementById("num1").value;
  var num2 = document.getElementById("num2").value;

  var n1 = parseFloat(num1);
  var n2 = parseFloat(num2);

  var res = n1 + n2;
  document.getElementById("result").innerHTML = res;
};

document.getElementById("sub").onclick = function () {
  var num1 = document.getElementById("num1").value;
  var num2 = document.getElementById("num2").value;

  var n1 = parseFloat(num1);
  var n2 = parseFloat(num2);

  var res = n1 - n2;
  document.getElementById("result").innerHTML = res;
};

document.getElementById("mul").onclick = function () {
  var num1 = document.getElementById("num1").value;
  var num2 = document.getElementById("num2").value;

  var n1 = parseFloat(num1);
  var n2 = parseFloat(num2);

  var res = n1 * n2;
  document.getElementById("result").innerHTML = res;
};

document.getElementById("division").onclick = function () {
  var num1 = document.getElementById("num1").value;
  var num2 = document.getElementById("num2").value;

  var n1 = parseFloat(num1);
  var n2 = parseFloat(num2);

  var res = n1 / n2;
  document.getElementById("result").innerHTML = res;
};
