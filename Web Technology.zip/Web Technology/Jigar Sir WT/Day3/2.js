document.getElementById("btn").onclick = function () {
  //   alert("Hello World!");

  //   confirm("Are you sure you want to proceed?");

  //   prompt("Enter your name:");

  //   console.log(document.getElementById("x1"));

  var data = document.getElementById("x1").value;
  console.log(data);

  var msg = "  ";

  //   if (data == "") {
  //     msg = "Please enter some data!";
  //   } else if (data.length != 6) {
  //     msg = "Please enter a 6-digit number!";
  //   } else {
  //     msg = "Pincode Valid input!";
  //   }

  var msg =
    data == ""
      ? "Please enter pincode!"
      : data.length != 6
      ? "Pincode should be 6 digits long!"
      : "Pincode Valid input!";

  console.log(document.getElementById("result"));
  document.getElementById("result").innerHTML = msg;
};
