"use strict";
document.getElementById("btn").onclick = function () {
  //  alert{ 'Hello World!' };
  var data1 = document.getElementById("x1").value;
  var data2 = document.getElementById("x2").value;
  var data3 = document.getElementById("x3").value;

  console.log(typeof data1);
  console.log(isNaN(data1));
  console.log(data1, data2, data3);

  var msg = " ";

  if (data1 == "" || data2 == "" || data3 == "") {
    msg = "Please enter all fields!";
  } else if (isNaN(data1) || isNaN(data2) || isNaN(data3)) {
    msg = "All fields should contain numeric values!";
  } else if (data1 < 0 || data2 < 0 || data3 < 0) {
    msg = "All fields should contain positive numeric values!";
  } else {
    var p = Number(data1);
    var r = parseFloat(data2);
    var n = parseInt(data3);

    r = r / 12 / 100;
    n = n * 12;

    var si = p * (1 + r * n);
    var intr = si - p;
    var totalamout = p + intr;

    intr = Math.round(intr);
    totalamout = Math.round(totalamout);

    document.getElementById("y1").innerHTML = p;
    document.getElementById("y2").innerHTML = intr;
    document.getElementById("y3").innerHTML = totalamout;
  }

  document.getElementById("result").innerHTML = msg;
};
