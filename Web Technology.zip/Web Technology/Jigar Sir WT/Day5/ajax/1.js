"use strict";
// DOM Event Listener for Button 1
document.getElementById("btn1").addEventListener("click", function () {
  var xmlhttp = new XMLHttpRequest();
  console.log(xmlhttp);
  console.log(xmlhttp.readyState);
  // if 0 - Request not initialized
  console.log(xmlhttp.status);

  // Event listener for when the request is ready to be sent
  xmlhttp.onreadystatechange = function () {
    console.log(xmlhttp.readyState, xmlhttp.status);
    if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
      console.log(xmlhttp.responseText);
      var res = JSON.parse(xmlhttp.responseText);
      console.log(res);

      res &&
        res.length > 0 &&
        res.forEach(function (v, i) {
          console.log(v, i);

          // Create wrapper div with aspect ratio class
          var divtag = document.createElement("div");
          var imgContainer = document.createElement("div"); // Add a container for the image
          var imgtag = document.createElement("img");
          var h2tag = document.createElement("h2");
          var ptag = document.createElement("p");

          // Set image source and other properties
          imgtag.src = v.image;
          h2tag.innerHTML = v.price;
          ptag.innerHTML = v.title;

          // Apply necessary classes
          divtag.className = "col-md-3 text-center";
          imgContainer.className = "img-container"; // Apply aspect ratio class
          imgtag.className = "img-fluid"; // Ensure responsiveness

          // Append image inside the aspect ratio container
          imgContainer.appendChild(imgtag);

          // Append all elements to the divtag
          divtag.append(imgContainer, h2tag, ptag);
          document.querySelector("#row").append(divtag);
        });
    }
    // 1 - works when open method initiated and request has been setup
  };

  xmlhttp.open("get", "https://fakestoreapi.com/products");
  // This method will help to perform fetching data from the server.

  xmlhttp.send();
  // It's send request to the server and readystate will become 2.
  // 3 - request is in progress mode
  // 4 - request cycle is complete and response is ready to be accessed
});
