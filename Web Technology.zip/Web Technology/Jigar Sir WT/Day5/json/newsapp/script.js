const API_KEY = "c941676199044e769cb466bbb36c8c54";
const URL = "https://newsapi.org/v2/everything?q=";

window.addEventListener("load", () => fetchNews("Headlines"));

async function fetchNews(queary) {
  // console.log(queary);

  let res = await fetch(`${URL}${queary}&from=2024-11-10&apiKey=${API_KEY}`);

  let data = await res.json();
  console.log(data);
  console.log(data.articles);
}

const bindNews = (articles) => {
  if (articles.length > 0) {
    var str = ` `;
    articles.forEach((artical) => {
      str += ` <div class="col-xl-4 news-card">
          <div class="card">
            <img
              src="${artical.urlToImage}"
              class="card-img-top"
              alt="bunlog"
            />
            <div class="card-body">
              <h5 class="card-title">${artical.title}</h5>
              <h6>${artical.source.name} 📢 ${artical.publishedAt}</h6>
              <p class="card-text">
                ${artical.description}</p>
              </p>
              <a href="${artical.url}" class="btn btn-primary" trget="_blank">Read More</a>
            </div>
          </div>
        </div>
        `;
      document.querySelector(".row").innerHTML = str;
    });
  }
};
